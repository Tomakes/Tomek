<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* bezoekers/default.html.twig */
class __TwigTemplate_7e78626a272236e05a51fc7301623745b3f437dc15d70eb9945f4400d7d31b96 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'menu' => [$this, 'block_menu'],
            'menu_right' => [$this, 'block_menu_right'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "../base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "bezoekers/default.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "bezoekers/default.html.twig"));

        $this->parent = $this->loadTemplate("../base.html.twig", "bezoekers/default.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\" style=\"background-color: white\">
        <header>
            <div class=\"row\" style=\"margin-top: 20px\">

                <div class=\"d-none d-md-block col-sm-1\">
                    <span class=\"fas fa-hand-holding-medical\" style=\"font-size:50px; color:red\"></span>
                </div>
                <div class=\"col-sm-11\">
                    <h1 >HealthOne <span class=\"text-danger\"> Today</span></h1>

                </div>

            </div>
            ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 17, $this->source); })()), "flashes", [0 => "notice"], "method", false, false, false, 17));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 18
            echo "                <div class=\"alert alert-success\">
                    <strong>Success!</strong> ";
            // line 19
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "            ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 22, $this->source); })()), "flashes", [0 => "error"], "method", false, false, false, 22));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 23
            echo "                <div class=\"alert alert-danger\">
                    <strong>Fout!</strong> Gebruiker ";
            // line 24
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "        </header>
        <nav class=\"navbar navbar-expand-sm bg-light navbar-light\" style=\"margin-bottom: 0px\">
            <a class=\"navbar-brand\" href=\"#\"><span class=\"fas fa-hospital\"></span> </a>
            <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#myNavbar\">
                <span class=\"navbar-toggler-icon\"></span>
            </button>


                <div class=\"collapse navbar-collapse\" id=\"myNavbar\">
                    <ul class=\"navbar-nav\">
                        ";
        // line 37
        $this->displayBlock('menu', $context, $blocks);
        // line 40
        echo "
                    </ul>
                    <ul class=\" navbar-nav ml-auto\">
                        ";
        // line 43
        $this->displayBlock('menu_right', $context, $blocks);
        // line 46
        echo "
                    </ul>
                </div>

        </nav>
        <figure>
            <img style=\"margin-bottom: 20px\" class=\"img-fluid\" src=";
        // line 52
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/healthone-wide.jpg"), "html", null, true);
        echo " />
        </figure>
        ";
        // line 54
        $this->displayBlock('content', $context, $blocks);
        // line 56
        echo "        <hr>
            <footer>

                <img class=\"float-right img-thumbnail\" width=\"40\"  style=\"margin-top: -10px;margin-bottom: 10px\" src=";
        // line 59
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/linkedin.jpg"), "html", null, true);
        echo " />
                <img class=\"float-right img-thumbnail\" width=\"40\"  style=\"margin-top: -10px;margin-bottom: 10px\" src=";
        // line 60
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/tweet.jpg"), "html", null, true);
        echo " />
                <img class=\"float-right img-thumbnail \" width=\"40\"  style=\"margin-top: -10px;margin-bottom: 10px\" src=";
        // line 61
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/pinterest.png"), "html", null, true);
        echo " />

                <p class=\"text-muted text-center\">&copy;afdeling applicatieontwikkelaar Tinwerf 10, 2544 ED Den Haag. Telefoon:088 666 3600 </p>
            </footer>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 37
    public function block_menu($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "menu"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "menu"));

        // line 38
        echo "
                        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 43
    public function block_menu_right($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "menu_right"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "menu_right"));

        // line 44
        echo "                            <li class=\"nav-item \"><a class=\"nav-link\" href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_login");
        echo "\">inloggen</a></li>
                        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 54
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 55
        echo "        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "bezoekers/default.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  238 => 55,  228 => 54,  215 => 44,  205 => 43,  194 => 38,  184 => 37,  168 => 61,  164 => 60,  160 => 59,  155 => 56,  153 => 54,  148 => 52,  140 => 46,  138 => 43,  133 => 40,  131 => 37,  119 => 27,  110 => 24,  107 => 23,  102 => 22,  93 => 19,  90 => 18,  86 => 17,  71 => 4,  61 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends '../base.html.twig' %}

{% block body %}
    <div class=\"container\" style=\"background-color: white\">
        <header>
            <div class=\"row\" style=\"margin-top: 20px\">

                <div class=\"d-none d-md-block col-sm-1\">
                    <span class=\"fas fa-hand-holding-medical\" style=\"font-size:50px; color:red\"></span>
                </div>
                <div class=\"col-sm-11\">
                    <h1 >HealthOne <span class=\"text-danger\"> Today</span></h1>

                </div>

            </div>
            {% for message in app.flashes('notice') %}
                <div class=\"alert alert-success\">
                    <strong>Success!</strong> {{ message }}
                </div>
            {% endfor %}
            {% for message in app.flashes('error') %}
                <div class=\"alert alert-danger\">
                    <strong>Fout!</strong> Gebruiker {{ message }}
                </div>
            {% endfor %}
        </header>
        <nav class=\"navbar navbar-expand-sm bg-light navbar-light\" style=\"margin-bottom: 0px\">
            <a class=\"navbar-brand\" href=\"#\"><span class=\"fas fa-hospital\"></span> </a>
            <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#myNavbar\">
                <span class=\"navbar-toggler-icon\"></span>
            </button>


                <div class=\"collapse navbar-collapse\" id=\"myNavbar\">
                    <ul class=\"navbar-nav\">
                        {% block menu %}

                        {% endblock %}

                    </ul>
                    <ul class=\" navbar-nav ml-auto\">
                        {% block menu_right %}
                            <li class=\"nav-item \"><a class=\"nav-link\" href=\"{{ path('app_login') }}\">inloggen</a></li>
                        {% endblock %}

                    </ul>
                </div>

        </nav>
        <figure>
            <img style=\"margin-bottom: 20px\" class=\"img-fluid\" src={{ asset('img/healthone-wide.jpg')}} />
        </figure>
        {% block content %}
        {% endblock %}
        <hr>
            <footer>

                <img class=\"float-right img-thumbnail\" width=\"40\"  style=\"margin-top: -10px;margin-bottom: 10px\" src={{ asset('img/linkedin.jpg')}} />
                <img class=\"float-right img-thumbnail\" width=\"40\"  style=\"margin-top: -10px;margin-bottom: 10px\" src={{ asset('img/tweet.jpg')}} />
                <img class=\"float-right img-thumbnail \" width=\"40\"  style=\"margin-top: -10px;margin-bottom: 10px\" src={{ asset('img/pinterest.png')}} />

                <p class=\"text-muted text-center\">&copy;afdeling applicatieontwikkelaar Tinwerf 10, 2544 ED Den Haag. Telefoon:088 666 3600 </p>
            </footer>
    </div>
{%  endblock %}", "bezoekers/default.html.twig", "C:\\xampp\\htdocs\\healthone2\\templates\\bezoekers\\default.html.twig");
    }
}
